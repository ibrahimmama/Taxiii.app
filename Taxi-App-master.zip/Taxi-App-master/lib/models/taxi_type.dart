enum TaxiType { Standard, Premium, Platinum }
