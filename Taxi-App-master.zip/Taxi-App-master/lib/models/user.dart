class User {
  final String name;
  final String mobileNumber;
  final String photoUrl;

  User({this.name, this.mobileNumber, this.photoUrl});
}
